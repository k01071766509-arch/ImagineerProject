import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/common.dart';

/// 9-2. 오늘의 메모
/// - 뒤로가기 → 9. 기록
/// - 메모 저장하기 → 저장 안내 후 9. 기록으로 돌아갑니다
/// - [변경/11-06] 기록 화면에서 고른 날짜의 실제 기록(점수·음원·메모)을 보여 주고 저장해요.
class RecordMemoScreen extends StatefulWidget {
  const RecordMemoScreen({super.key});

  @override
  State<RecordMemoScreen> createState() => _RecordMemoScreenState();
}

class _RecordMemoScreenState extends State<RecordMemoScreen> {
  GrowthStore get _store => GrowthStore.instance;

  /// 기록 화면에서 고른 날짜 (없으면 오늘)
  late final DateTime _date = _store.memoTargetDate ?? dayOf(DateTime.now());
  late final DayRecord? _record = _store.recordOn(_date);
  late final TextEditingController _controller = TextEditingController(text: _record?.memo ?? '');

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    FocusScope.of(context).unfocus();
    _store.saveMemo(_date, _controller.text);
    showMockSnack(context, '메모를 저장했어요');
    Nav.backTo(context, AppRoutes.records);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Padding(
          padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, bottomPad(context, 32)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              CenterTitleHeader(
                title: '${_date.month}월 ${_date.day}일의 메모',
                onBack: () => Nav.backTo(context, AppRoutes.records),
              ),
              const SizedBox(height: 24),
              AppCard(
                radius: 16,
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('웰니스 스코어', style: ts(12, color: AppColors.textSub)),
                    Text(
                      _record == null
                          ? '기록 없음'
                          : '${_record!.wellness.round()}점${_record!.soundTitle == null ? '' : ' · ${_record!.soundTitle}'}',
                      style: ts(14, weight: bold, color: AppColors.primary),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Text('오늘 하루는 어땠나요?', style: ts(13, weight: bold)),
              const SizedBox(height: 10),
              Expanded(
                child: AppCard(
                  padding: const EdgeInsets.all(18),
                  child: TextField(
                    controller: _controller,
                    maxLines: null,
                    expands: true,
                    textAlignVertical: TextAlignVertical.top,
                    style: ts(14, height: 1.7),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      isCollapsed: true,
                      hintText: '오늘의 메모',
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              PrimaryButton(label: '메모 저장하기', onTap: _save),
            ],
          ),
        ),
      ),
    );
  }
}
