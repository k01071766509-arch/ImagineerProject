// [추가/11-01] 1031 회의 반영: 필사 탭 분리 · 필사로 물고기 성장 · 어항 배경음
// [추가/11-06] 날짜별 기록 · 연속 기록 · 6개월 보관 · 어항 수질 변화
//
// 앱 전체에서 함께 쓰는 "성장 상태"를 한곳에 모았어요.
// - 오늘의 물고기: 웰니스 스코어(활력·안정·불안·피로) 중 가장 높은 유형
// - 필사 문구: 4가지 카테고리, 오늘의 유형에 맞는 문구를 추천
// - 경험치: 추천 문구를 필사하면 해당 물고기만 경험치를 얻어요 (가장 높은 감정 하나만 반영)
// - 어항 배경음: 그날의 음원(오늘 들은 음원, 없으면 오늘 추천 음원)을 어항에서 다시 듣기
//
// ⚠️ 지금은 앱을 끄면 초기화되는 메모리 저장이에요.
//    Firestore 저장은 데이터 구조가 확정되면 이 파일 안에서만 바꾸면 돼요.

import 'package:flutter/foundation.dart';

import '../widgets/fish_widgets.dart' show FishType;
import 'analysis_service.dart';

// ───────────────────────── 경험치 규칙 (회의에서 숫자만 바꾸면 돼요) ─────────────────────────

/// 추천 문구 하나를 필사하면 얻는 경험치
const int expPerTranscript = 10;

/// 다음 레벨까지 필요한 경험치 (Lv.1→2, 2→3, 3→4, 4→5)
/// 기본값 기준: 한 물고기를 만렙(Lv.5)까지 키우려면 필사 14번
const List<int> expToNextLevel = [20, 30, 40, 50];

/// [테스트용] 녹음 없이 필사·어항 기능을 확인하고 싶을 때 오늘의 유형을 정해 둬요.
/// 예) FishType.calm 으로 바꾸면 '안정'이 오늘의 물고기가 됩니다. 확인이 끝나면 null 로 되돌리기
const FishType? demoTodayType = null;

/// [회의 확인용] true = 어항에 오늘의 물고기만 표시 / false = 4마리 모두 표시하고 오늘의 물고기만 강조
const bool showOnlyTodayFish = false;

// ───────────────────────── [추가/11-06] 기록 · 연속 기록 · 수질 변화 ─────────────────────────
// ※ 녹음 파일은 저장하지 않아요. 날짜별로 분석 결과(점수·유형·영역)와 들은 음원, 메모만 남겨요.

/// 기록 보관 기간: 6개월(183일)이 지난 기록은 자동으로 지워져요. (물고기 레벨과 문장 노트는 유지)
const int recordKeepDays = 183;

/// 지워지기 며칠 전부터 안내할지
const int recordExpireNoticeDays = 7;

/// 수질 변화 단계: 마지막 기록 후 경과일 [1단계, 2단계, 3단계]
/// 5일: 살짝 탁해짐 / 10일: 더 탁해지고 천천히 헤엄 / 20일: 수초가 처지고 물고기가 바닥 근처에서 쉼
/// 레벨과 경험치는 절대 줄지 않아요. 다시 기록하면 바로 맑아져요.
const List<int> waterStageDays = [5, 10, 20];

/// [테스트용] 지난 기록을 미리 만들어 둬요. 둘 다 0/null 이면 사용 안 함
/// - demoStreakDays: 연속으로 기록한 날 수 (예: 7 → 7일 연속 기록)
/// - demoLastRecordDaysAgo: 그 연속 기록의 마지막 날이 며칠 전인지 (예: 12 → 12일 전, 수질 2단계 확인용)
/// 확인이 끝나면 0 / null 로 되돌리기
const int demoStreakDays = 0;
const int? demoLastRecordDaysAgo = null;

// ───────────────────────── 필사 문구 (4가지 카테고리) ─────────────────────────

/// 카테고리별 필사 문구. 팀에서 정한 문구로 자유롭게 바꾸거나 늘려도 돼요.
const Map<FishType, List<String>> transcriptPhrases = {
  FishType.vitality: [
    '오늘의 반짝임은 내일의 나에게도 이어질 거예요.',
    '작은 기쁨을 알아보는 마음이 하루를 밝혀요.',
    '지금의 설렘을 천천히 오래 간직해요.',
    '내가 웃을 수 있었던 순간을 잊지 말아요.',
    '좋은 에너지는 나를 지나 누군가에게도 닿아요.',
  ],
  FishType.calm: [
    '천천히 걸어도 괜찮아요. 방향이 맞다면 충분해요.',
    '고요한 마음은 가장 단단한 쉼터예요.',
    '오늘은 이대로도 충분히 괜찮은 하루예요.',
    '숨을 고르고, 지금 이 순간에 머물러요.',
    '잔잔한 물결처럼 내 마음도 제자리를 찾아가요.',
  ],
  FishType.anxiety: [
    '걱정은 잠시 내려놓아도 괜찮아요.',
    '모든 것을 지금 해결하지 않아도 돼요.',
    '흔들리는 마음도 결국 제자리를 찾아요.',
    '불안은 내가 소중한 것을 지키고 있다는 신호예요.',
    '한 걸음씩, 할 수 있는 것부터 해 봐요.',
  ],
  FishType.fatigue: [
    '쉬어가는 것도 나아가는 방법이에요.',
    '오늘 하루 버텨 낸 나에게 고마워요.',
    '지친 날에는 조금 느려도 괜찮아요.',
    '충분히 쉬어야 다시 걸을 힘이 생겨요.',
    '오늘의 나에게 조금 더 다정하게.',
  ],
};

// ───────────────────────── 음원 목록 ─────────────────────────

/// 앱 안의 음원 정보. Firebase에 음원이 올라오면 [url]을 채우면 돼요.
class SoundItem {
  const SoundItem({required this.id, required this.title, required this.desc, this.url});

  final String id;
  final String title;
  final String desc;
  final String? url; // Firebase Storage 주소 (아직 비어 있음)
}

const List<SoundItem> soundCatalog = [
  SoundItem(id: 'water_echo', title: '물빛의 잔향', desc: '물속에 번지는 맑은 건반 사운드'),
  SoundItem(id: 'game_world', title: '게임 속 작은 세상', desc: '통통 튀는 게임 속 분위기의 사운드'),
  SoundItem(id: 'spring', title: '맑은 샘물 소리', desc: '바위 사이로 흐르는 맑은 샘물 소리'),
  SoundItem(id: 'rain', title: '잔잔한 빗소리', desc: '숨을 천천히 내쉬어 보세요'),
];

/// 오늘의 추천 음원 3곡 (사운드 추천 화면에 나오는 순서: 추천 카드 1개 + 아래 2개)
/// TODO(사운드): 사운드 추천 로직이 연결되면 분석 결과에 맞는 3곡 id를 돌려주도록 바꿔요.
const List<String> todayRecommendedSoundIds = ['water_echo', 'game_world', 'spring'];

SoundItem? soundById(String? id) {
  for (final s in soundCatalog) {
    if (s.id == id) return s;
  }
  return null;
}

// ───────────────────────── 데이터 모델 ─────────────────────────

/// 물고기 한 마리의 성장 상태
class FishProgress {
  FishProgress({this.level = 1, this.exp = 0});

  int level; // 1(치어) ~ 5(완성)
  int exp; //   현재 레벨 안에서 모은 경험치

  bool get isMax => level >= FishType.maxLevel;

  /// 다음 레벨까지 필요한 경험치 (만렙이면 마지막 단계 값으로 표시)
  int get maxExp => expToNextLevel[(level - 1).clamp(0, expToNextLevel.length - 1)];
}

/// 필사 기록 한 건
class TranscriptRecord {
  const TranscriptRecord({required this.date, required this.phrase, this.type, this.soundTitle});

  final DateTime date;
  final String phrase;
  final FishType? type; //      null 이면 '작은 행운' 필사
  final String? soundTitle; //  필사할 때 재생 중이던 어항 배경음
}

/// 필사를 마쳤을 때의 결과 (화면에서 레벨업 안내에 사용)
class TranscriptReward {
  const TranscriptReward({required this.type, required this.gainedExp, required this.leveledUp, required this.level});

  final FishType type;
  final int gainedExp;
  final bool leveledUp;
  final int level;
}

/// 하루 한 건의 기록 (그날 마지막 분석 결과로 덮어써요)
class DayRecord {
  DayRecord({required this.date, required this.wellness, required this.type, this.area, this.soundTitle, this.memo});

  final DateTime date; // 날짜만 (시간 없음)
  double wellness; //     웰니스 스코어 0~100
  FishType type; //       가장 높았던 유형
  String? area; //        영역 (일/학업 등)
  String? soundTitle; //  그날 들은 음원
  String? memo; //        오늘의 메모
}

DateTime dayOf(DateTime d) => DateTime(d.year, d.month, d.day);

// ───────────────────────── [추가/11-06] 이번 주 영역별 리포트 ─────────────────────────

/// 리포트에서 쓰는 영역 목록 (임시). TODO(서버): 서버 담당 팀원과 목록이 정해지면 여기만 바꿔요.
const List<String> reportAreas = ['일/학업', '대인관계', '가족', '건강', '나 자신', '기타'];

/// 이번 주에 며칠 기록하면 리포트가 열리는지
const int weeklyReportMinDays = 3;

/// 서버에서 오는 영역 글자를 위 목록 중 하나로 맞춰요. (표현이 조금 달라도 같은 영역으로 모이게)
String normalizeArea(String? raw) {
  final a = (raw ?? '').trim();
  if (a.isEmpty) return '기타';
  if (reportAreas.contains(a)) return a;
  bool has(List<String> keys) => keys.any(a.contains);
  if (has(['가족', '부모', '엄마', '아빠', '형제', '자매'])) return '가족';
  if (has(['일', '학업', '공부', '학교', '시험', '과제', '직장', '회사', '업무', '진로', '취업'])) return '일/학업';
  if (has(['대인', '관계', '친구', '연애', '동료', '사람'])) return '대인관계';
  if (has(['건강', '몸', '수면', '잠', '운동', '아픔', '피로'])) return '건강';
  if (has(['자신', '자아', '자존', '감정', '마음'])) return '나 자신';
  return '기타';
}

/// 영역 하나의 이번 주 통계
class AreaStat {
  AreaStat(this.area, this.count, this.avgScore);
  final String area;
  final int count; //       이야기한 날 수
  final double avgScore; // 그 영역 평균 점수
}

/// 이번 주(월~일) 리포트
class WeeklyReport {
  WeeklyReport({
    required this.weekStart,
    required this.days,
    required this.avgScore,
    required this.diffFromLastWeek,
    required this.areas,
  });

  final DateTime weekStart; //       이번 주 월요일
  final int days; //                 이번 주 기록한 날 수
  final double? avgScore; //         이번 주 평균 점수 (기록 없으면 null)
  final double? diffFromLastWeek; // 지난주 평균과의 차이 (지난주 기록 없으면 null)
  final List<AreaStat> areas; //     많이 이야기한 순

  DateTime get weekEnd => weekStart.add(const Duration(days: 6));
  bool get unlocked => days >= weeklyReportMinDays;

  /// 한 줄 코멘트 (낮은 점수를 경고처럼 말하지 않아요)
  String get comment {
    if (areas.isEmpty) return '';
    final top = areas.first;
    var best = areas.first;
    for (final a in areas) {
      if (a.avgScore > best.avgScore) best = a;
    }
    final first = "이번 주엔 '${top.area}' 이야기를 가장 많이 했어요.";
    if (areas.length == 1 || best.area == top.area) return first;
    return "$first '${best.area}' 이야기를 한 날 마음이 가장 편했어요.";
  }
}

// ───────────────────────── 상태 저장소 ─────────────────────────

class GrowthStore extends ChangeNotifier {
  GrowthStore._();
  static final GrowthStore instance = GrowthStore._();

  /// 처음에는 4마리 모두 치어(Lv.1)
  final Map<FishType, FishProgress> fish = {for (final t in FishType.values) t: FishProgress()};

  final List<TranscriptRecord> transcripts = [];

  // ── [추가/11-06] 날짜별 기록 ──

  final List<DayRecord> _records = [];
  AnalysisResult? _recordedResult;
  bool _demoSeeded = false;

  /// 오랜만에 돌아와 기록했을 때 어항에서 인사할지 (어항 화면이 보여 주고 끕니다)
  bool welcomeBack = false;

  /// 메모 화면에서 편집할 날짜
  DateTime? memoTargetDate;

  /// 최근 6개월 기록 (오래된 순)
  List<DayRecord> get records {
    _sync();
    return List.unmodifiable(_records);
  }

  DayRecord? recordOn(DateTime day) {
    _sync();
    final d = dayOf(day);
    for (final r in _records) {
      if (r.date == d) return r;
    }
    return null;
  }

  /// 연속 기록 일수 (오늘 또는 어제까지 하루도 빠짐없이 기록한 날 수)
  int get streak {
    _sync();
    if (_records.isEmpty) return 0;
    final days = {for (final r in _records) r.date};
    var d = dayOf(DateTime.now());
    if (!days.contains(d)) d = d.subtract(const Duration(days: 1));
    var count = 0;
    while (days.contains(d)) {
      count++;
      d = d.subtract(const Duration(days: 1));
    }
    return count;
  }

  bool get recordedToday => recordOn(DateTime.now()) != null;

  /// 마지막 기록 후 지난 날 수 (기록이 하나도 없으면 null)
  int? get daysSinceLastRecord {
    _sync();
    if (_records.isEmpty) return null;
    return dayOf(DateTime.now()).difference(_records.last.date).inDays;
  }

  /// 수질 단계 0(맑음) ~ 3. 처음 쓰는 사람(기록 없음)은 항상 맑음
  int get waterStage {
    final d = daysSinceLastRecord;
    if (d == null) return 0;
    var stage = 0;
    for (final limit in waterStageDays) {
      if (d >= limit) stage++;
    }
    return stage;
  }

  /// 7일 안에 6개월이 지나 지워질 기록 수
  int get expiringSoonCount {
    _sync();
    final today = dayOf(DateTime.now());
    return _records.where((r) => today.difference(r.date).inDays >= recordKeepDays - recordExpireNoticeDays).length;
  }

  /// 새 분석 결과를 기록에 반영하고, 6개월 지난 기록을 지워요. (알림 없이 조용히)
  void _sync() {
    if (!_demoSeeded) {
      _demoSeeded = true;
      _seedDemo();
    }
    final r = AnalysisSession.instance.result;
    if (r != null && !identical(r, _recordedResult)) {
      _recordedResult = r;
      final today = dayOf(DateTime.now());
      final before = _records.isEmpty ? null : today.difference(_records.last.date).inDays;
      if (before != null && before >= waterStageDays.first) welcomeBack = true;
      final existing = _records.where((e) => e.date == today).toList();
      final type = todayType ?? FishType.vitality;
      if (existing.isEmpty) {
        _records.add(DayRecord(date: today, wellness: r.wellnessScore, type: type, area: r.area));
      } else {
        existing.first
          ..wellness = r.wellnessScore
          ..type = type
          ..area = r.area;
      }
    }
    final cutoff = dayOf(DateTime.now()).subtract(const Duration(days: recordKeepDays));
    _records.removeWhere((e) => e.date.isBefore(cutoff));
    _records.sort((a, b) => a.date.compareTo(b.date));
  }

  void _seedDemo() {
    final last = demoLastRecordDaysAgo;
    if (demoStreakDays <= 0 && last == null) return;
    final end = dayOf(DateTime.now()).subtract(Duration(days: last ?? 0));
    final n = demoStreakDays <= 0 ? 1 : demoStreakDays;
    const sounds = ['물빛의 잔향', '맑은 샘물 소리', '잔잔한 빗소리'];
    for (var i = n - 1; i >= 0; i--) {
      _records.add(DayRecord(
        date: end.subtract(Duration(days: i)),
        wellness: 55.0 + (i * 7) % 35,
        type: FishType.values[i % FishType.values.length],
        area: const ['일/학업', '대인관계', '일/학업', '나 자신', '가족'][i % 5],
        soundTitle: sounds[i % sounds.length],
      ));
    }
  }

  void _attachSoundToToday(String id) {
    final rec = recordOn(DateTime.now());
    final s = soundById(id);
    if (rec != null && s != null) rec.soundTitle = s.title;
  }

  /// [추가/11-06] 이번 주(월~일) 영역별 리포트
  WeeklyReport weeklyReport() {
    _sync();
    final today = dayOf(DateTime.now());
    final start = today.subtract(Duration(days: today.weekday - 1));
    final lastStart = start.subtract(const Duration(days: 7));
    final end = start.add(const Duration(days: 7));

    final thisWeek = _records.where((r) => !r.date.isBefore(start) && r.date.isBefore(end)).toList();
    final lastWeek = _records.where((r) => !r.date.isBefore(lastStart) && r.date.isBefore(start)).toList();

    double? avg(List<DayRecord> list) =>
        list.isEmpty ? null : list.map((r) => r.wellness).reduce((a, b) => a + b) / list.length;

    final grouped = <String, List<DayRecord>>{};
    for (final r in thisWeek) {
      grouped.putIfAbsent(normalizeArea(r.area), () => []).add(r);
    }
    final areas = [for (final e in grouped.entries) AreaStat(e.key, e.value.length, avg(e.value)!)]
      ..sort((a, b) {
        final c = b.count.compareTo(a.count);
        return c != 0 ? c : reportAreas.indexOf(a.area).compareTo(reportAreas.indexOf(b.area));
      });

    final now = avg(thisWeek);
    final before = avg(lastWeek);
    return WeeklyReport(
      weekStart: start,
      days: thisWeek.length,
      avgScore: now,
      diffFromLastWeek: (now != null && before != null) ? now - before : null,
      areas: areas,
    );
  }

  void saveMemo(DateTime day, String memo) {
    final rec = recordOn(day);
    if (rec == null) return;
    rec.memo = memo.trim().isEmpty ? null : memo.trim();
    notifyListeners();
  }

  /// 마이페이지 '데이터 초기화': 기록, 물고기, 문장 노트, 음원 선택을 모두 처음 상태로
  void resetAll() {
    _records.clear();
    _recordedResult = AnalysisSession.instance.result; // 지금 결과가 다시 기록되지 않게
    welcomeBack = false;
    for (final f in fish.values) {
      f
        ..level = 1
        ..exp = 0;
    }
    transcripts.clear();
    _rewardedKey = null;
    _phraseKey = null;
    _soundKey = null;
    _todaySoundId = null;
    bgmPlaying = false;
    notifyListeners();
  }

  // ── 오늘의 물고기 ──

  static final Object _demoKey = Object();

  /// 오늘의 분석 결과를 가리키는 값. 새로 녹음하면 바뀌어서 새 추천 문구가 나와요.
  Object? get _todayKey => AnalysisSession.instance.result ?? (demoTodayType != null ? _demoKey : null);

  /// 웰니스 스코어에서 가장 높은 유형. 아직 녹음하지 않았으면 null
  FishType? get todayType {
    final r = AnalysisSession.instance.result;
    if (r == null) return demoTodayType;
    final scores = {
      FishType.vitality: r.vitality,
      FishType.calm: r.calm,
      FishType.anxiety: r.anxiety,
      FishType.fatigue: r.fatigue,
    };
    var best = FishType.vitality;
    for (final e in scores.entries) {
      if (e.value > scores[best]!) best = e.key;
    }
    return best;
  }

  // ── 오늘의 추천 문구 ──

  Object? _phraseKey;
  String? _phrase;
  final Map<FishType, int> _nextPhraseIndex = {for (final t in FishType.values) t: 0};

  /// 오늘의 유형에 맞는 추천 문구 (분석 결과 하나당 한 문구, 녹음할 때마다 다음 문구로)
  String? get todayPhrase {
    final type = todayType;
    final key = _todayKey;
    if (type == null || key == null) return null;
    if (!identical(key, _phraseKey)) {
      final list = transcriptPhrases[type]!;
      final i = _nextPhraseIndex[type]!;
      _phrase = list[i % list.length];
      _nextPhraseIndex[type] = i + 1;
      _phraseKey = key;
    }
    return _phrase;
  }

  Object? _rewardedKey;

  /// 오늘의 추천 문구를 이미 필사했는지 (분석 결과 하나당 경험치는 한 번만)
  bool get todayDone {
    final key = _todayKey;
    return key != null && identical(key, _rewardedKey);
  }

  /// 추천 문구 필사 완료 → 오늘의 물고기에 경험치
  TranscriptReward? completeTodayTranscript() {
    final type = todayType;
    final phrase = todayPhrase;
    if (type == null || phrase == null || todayDone) return null;

    _rewardedKey = _todayKey;
    transcripts.insert(0, TranscriptRecord(date: DateTime.now(), phrase: phrase, type: type, soundTitle: _bgmTitleIfPlaying));

    final f = fish[type]!;
    var leveledUp = false;
    if (!f.isMax) {
      f.exp += expPerTranscript;
      while (!f.isMax && f.exp >= f.maxExp) {
        f.exp -= f.maxExp;
        f.level++;
        leveledUp = true;
      }
      if (f.isMax) f.exp = f.maxExp; // 만렙이면 게이지를 꽉 채워 보여 줘요
    }
    notifyListeners();
    return TranscriptReward(type: type, gainedExp: expPerTranscript, leveledUp: leveledUp, level: f.level);
  }

  /// 작은 행운(홈) 필사 저장 — 감정 카테고리가 없어서 경험치는 없어요
  void addLuckyTranscript(String phrase) {
    transcripts.insert(0, TranscriptRecord(date: DateTime.now(), phrase: phrase, soundTitle: _bgmTitleIfPlaying));
    notifyListeners();
  }

  // ── 그날의 음원 (어항 배경음) ──
  // [변경/11-01] 수집 음원 중 고르기 → '그날의 음원'을 어항에서 다시 듣기로 변경

  /// 지금 재생 화면에서 듣는 음원 (사운드 추천 → 재생으로 넘길 때 사용)
  String? nowPlayingId;

  /// 오늘 분석 뒤에 직접 들은 음원
  Object? _soundKey;
  String? _todaySoundId;

  bool bgmPlaying = false;

  /// 그날의 음원 (어항에서 지금 선택된 곡)
  /// - 어항에서 직접 고른 곡, 또는 오늘 분석 뒤 사운드 재생 화면에서 마지막으로 들은 곡
  /// - 아직 아무것도 듣지 않았으면 오늘 추천 1순위 곡
  /// - 오늘 녹음 전이면 null
  SoundItem? get todaySound {
    final key = _todayKey;
    if (key == null) return null;
    if (identical(key, _soundKey)) return soundById(_todaySoundId);
    return soundById(todayRecommendedSoundIds.first);
  }

  /// 어항에서 고를 수 있는 오늘의 곡들 (추천 3곡 + 추천 밖에서 들은 곡이 있으면 함께)
  List<SoundItem> get todaySounds {
    if (_todayKey == null) return const [];
    final ids = [...todayRecommendedSoundIds];
    final current = todaySound?.id;
    if (current != null && !ids.contains(current)) ids.add(current);
    return [for (final id in ids) if (soundById(id) != null) soundById(id)!];
  }

  /// 어항에서 곡 고르기 → 바로 재생
  void selectTodaySound(String id) {
    final key = _todayKey;
    if (key == null) return;
    _soundKey = key;
    _todaySoundId = id;
    bgmPlaying = true;
    _attachSoundToToday(id);
    notifyListeners();
    // TODO(사운드): 실제 재생 연결 (todaySound?.url)
  }

  String? get _bgmTitleIfPlaying => bgmPlaying ? todaySound?.title : null;

  void startSound(String id, {bool notify = true}) {
    nowPlayingId = id;
    final key = _todayKey;
    if (key != null) {
      _soundKey = key;
      _todaySoundId = id;
      _attachSoundToToday(id);
    }
    if (notify) notifyListeners();
  }

  void toggleBgm() {
    if (todaySound == null) return;
    bgmPlaying = !bgmPlaying;
    notifyListeners();
    // TODO(사운드): Firebase 음원이 준비되면 여기서 실제 재생/일시정지를 연결해요. (todaySound?.url)
  }
}
