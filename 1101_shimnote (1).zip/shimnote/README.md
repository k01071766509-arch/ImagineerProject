# 쉼노트 (ShimNote) – Flutter UI

목소리로 오늘의 감정을 기록하고, 웰니스 스코어와 힐링 사운드를 추천받는 앱의 UI입니다.
"쉼노트 UI 목업"의 16개 화면과 화면 간 이동을 Flutter로 옮겼습니다.

## 실행 방법 (VS Code)

1. 압축을 풀고 VS Code에서 `shimnote` 폴더를 엽니다.
2. 터미널에서 플랫폼 폴더(android, ios 등)를 만들어 줍니다. 기존 `lib/` 코드는 덮어쓰지 않습니다.
   ```bash
   flutter create .
   ```
3. 패키지를 받고 실행합니다.
   ```bash
   flutter pub get
   flutter run
   ```

- Flutter 3.27 이상이 필요합니다.
- 폰트(Noto Sans KR, Gowun Dodum)는 `google_fonts` 패키지가 처음 실행 때 인터넷에서 받아옵니다.
  에뮬레이터/기기가 인터넷에 연결되어 있어야 해요.

## 폴더 구조

```
lib/
├── main.dart                     앱 시작, 테마, 라우터 설정
├── navigation/
│   ├── app_routes.dart           16개 화면 라우트 이름과 연결
│   └── nav.dart                  화면 이동 헬퍼 (push / replace / 탭 이동 / 뒤로가기)
├── theme/
│   ├── app_colors.dart           목업 색상
│   └── app_text.dart             텍스트 스타일 헬퍼
├── widgets/
│   ├── app_icons.dart            목업 SVG 아이콘
│   ├── common.dart               카드, 버튼, 헤더, 안내 박스 등 공통 위젯
│   ├── bottom_nav.dart           하단 탭바 (홈 / 기록 / (필사) / 어항)
│   ├── animations.dart           퍼지는 원, 통통 튀는 애니메이션
│   ├── record_widgets.dart       달력, 필사 목록
│   └── fish_widgets.dart         어항 배경, 헤더, 물고기 레벨 카드
└── screens/                      16개 화면
assets/images/logo.png            스플래시 로고
assets/fish/                      물고기 4종 × 5레벨 SVG (fish_<유형>_lv<1~5>.svg)
```

## 화면 목록과 연결

| 번호 | 화면 | 파일 | 이동 |
|---|---|---|---|
| 1 | 스플래시 | `splash_screen.dart` | 2초 후(또는 탭) → 온보딩 |
| 2 | 온보딩 | `onboarding_screen.dart` | 게스트로 시작하기 → 홈 |
| 3 | 메인(홈) | `home_screen.dart` | 하루 기록하기 → 감정 담기 / 오늘의 필사 카드 (녹음 전 → 감정 담기, 녹음 후 → 필사 탭) / 탭: 기록, 필사, 어항 |
| 3-1 | 작은 행운 | `lucky_screen.dart` | 11-01부터 홈에서 연결하지 않음 (오늘의 필사 카드로 대체) |
| 4 | 감정 담기 | `recording_screen.dart` | ← 홈 / 녹음 완료 → 분석 (대기·녹음 중·오류 상태 포함) |
| 5 | 분석 | `analyzing_screen.dart` | 3초 후(또는 탭) → 웰니스 스코어 |
| 6 | 웰니스 스코어 | `wellness_score_screen.dart` | ← 감정 담기 / 추천 사운드 듣기 → 사운드 추천 |
| 7 | 사운드 추천 | `sound_recommend_screen.dart` | ← 웰니스 스코어 / 사운드 카드 → 사운드 재생 / 탭: 홈, 기록, 어항 |
| 8 | 사운드 재생 | `sound_play_screen.dart` | ← 사운드 추천 / 재생·일시정지 / 힐링 종료 → 홈 |
| 9 | 기록 | `records_screen.dart` | 캘린더 / 오늘의 메모 → 9-2 / 첫 사용자 화면 보기 → 9-1 / 탭: 홈, 필사, 어항 |
| 9-1 | 기록(첫 사용자) | `records_empty_screen.dart` | 기록 있는 화면 보기 → 9 / 감정 담으러 가기 → 홈 |
| 9-2 | 오늘의 메모 | `record_memo_screen.dart` | ← 기록 / 메모 저장하기 → 기록 |
| 9-3 | 필사 | `transcripts_screen.dart` (하단 탭) | 오늘의 감정 문구 추천 → 따라 적기 → 오늘의 물고기 경험치 / 카테고리별 필사 기록 |
| 10 | 어항 | `fish_tank_screen.dart` | 4마리 치어로 시작, 오늘의 물고기 강조 + 말풍선(→ 필사 탭) / 그날의 음원 다시 듣기 / 설정 → 마이페이지 |
| 10-1 | 어항(첫 사용자) | `fish_tank_empty_screen.dart` | 11-01부터 어항 화면에서 연결하지 않음 (4마리 모두 치어로 시작하므로) |
| 11 | 마이페이지 | `my_page_screen.dart` | ← 어항 / 데이터 초기화 안내 열기·닫기 |

### 화면 이동 방식

- **앞으로 가기**는 `Nav.push` 로 화면을 쌓습니다. (기기의 뒤로가기 버튼도 동작해요)
- **하단 탭**은 `Nav.resetTo` 로 스택을 비우고 해당 탭 화면에서 다시 시작합니다.
- **화면 안의 `<` 버튼**은 `Nav.backTo` 로 목업에 지정된 화면으로 돌아갑니다.
- 분석 화면은 결과 화면으로 넘어가면 스택에서 빠집니다(`Nav.replace`).

## 물고기

| 유형 | 코드 이름 | 색 |
|---|---|---|
| 활력 | `FishType.vitality` | 노랑 |
| 안정 | `FishType.calm` | 초록 |
| 불안 | `FishType.anxiety` | 빨강 |
| 피로 | `FishType.fatigue` | 파랑 |

`FishSprite(type: FishType.calm, level: 4, size: 120)` 처럼 쓰면 됩니다. (`lib/widgets/fish_widgets.dart`)
레벨: 1 치어 → 2 꼬마 → 3 성장 → 4 성숙 → 5 완성. 그림은 같은 크기 캔버스 안에서 레벨이 오를수록 커져요.

## 1031 회의 반영 (11-01)

| 내용 | 파일 |
|---|---|
| 필사를 기록 탭에서 빼서 **별도 하단 탭**으로 (홈 / 기록 / 필사 / 어항) | `bottom_nav.dart`, `records_screen.dart`, `transcripts_screen.dart` |
| 필사 문구 **활력·안정·불안·피로 4카테고리** (각 5문장) | `services/growth_store.dart` → `transcriptPhrases` |
| ① 웰니스 스코어 최고 유형 = 오늘의 물고기 → ② 어항에 강조 표시 → ③ 필사 탭에서 그 유형 문구 추천 → ④ 따라 적기 → ⑤ 경험치 → ⑥ 레벨업 | `growth_store.dart`, `transcripts_screen.dart`, `fish_tank_screen.dart` |
| 어항 배경음: **그날의 음원**을 어항·필사 탭에서 다시 듣기. '곡 선택'을 누르면 오늘 추천 3곡 중 하나를 체크해서 고를 수 있어요 (처음엔 오늘 마지막으로 들은 곡) | `widgets/bgm_bar.dart`, `sound_recommend_screen.dart`, `sound_play_screen.dart` |
| 홈의 '작은 행운' 카드 → **오늘의 필사** 카드 (필사 탭과 겹쳐서 하나로 합침) | `home_screen.dart` |

**정해 둔 규칙 (숫자는 `growth_store.dart` 맨 위에서 바꾸면 돼요)**
- 처음엔 4마리 모두 Lv.1 치어
- 추천 문구 필사 1번 = 경험치 10, 분석 결과 1번당 1번만 (다시 녹음하면 새 문구)
- 다음 레벨까지 20 / 30 / 40 / 50 → 한 마리를 만렙까지 필사 14번
- `showOnlyTodayFish = true`로 바꾸면 어항에 오늘의 물고기만 보여요

**테스트**: 녹음 없이 확인하려면 `growth_store.dart`의 `demoTodayType`을 `FishType.calm` 등으로 바꿔요. (확인 후 `null`로)

**남은 일**
- 성장 상태는 아직 메모리에만 저장 (앱을 끄면 초기화) → Firestore 저장 필요
- 배경음 실제 재생: Firebase 음원이 올라오면 `growth_store.dart`의 `TODO(사운드)` 부분에 연결
- 만렙 이후 운영 방안은 회의에서 결정 예정

## 아직 목업 수준인 부분

실제 녹음, 감정 분석 API, 사운드 재생, 데이터 저장은 연결되어 있지 않고 목업의 예시 데이터를 보여 줍니다.
기능을 붙일 때는 각 화면의 예시 값(점수 72, 날짜 9월 17일 등)을 상태 관리나 API 결과로 바꾸면 됩니다.
