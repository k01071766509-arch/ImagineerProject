import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import 'app_icons.dart';
import 'common.dart';

enum NavTab { home, records, transcripts, fishTank, none }

/// 하단 탭바 (홈 / 기록 / 필사 / 어항)
/// [변경/11-01] 1031 회의: 필사를 기록 탭에서 빼서 별도 탭으로 항상 보여 줘요.
class AppBottomNav extends StatelessWidget {
  const AppBottomNav({super.key, required this.current, this.showTranscripts = true});

  final NavTab current;

  /// 예전 코드와의 호환용 (이제 필사 탭은 항상 보여요)
  final bool showTranscripts;

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).padding.bottom;
    return Container(
      height: 76 + bottomInset,
      padding: EdgeInsets.only(bottom: bottomInset),
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(top: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _item(context, NavTab.home, '홈', AppRoutes.home, AppIcons.home),
          _item(context, NavTab.records, '기록', AppRoutes.records, AppIcons.calendar),
          _item(context, NavTab.transcripts, '필사', AppRoutes.transcripts, AppIcons.pencil),
          _item(context, NavTab.fishTank, '어항', AppRoutes.fishTank, AppIcons.waves),
        ],
      ),
    );
  }

  Widget _item(
    BuildContext context,
    NavTab tab,
    String label,
    String route,
    String Function(Color) icon,
  ) {
    final active = tab == current;
    final color = active ? AppColors.primary : AppColors.textMuted;
    return Expanded(
      child: Tap(
        onTap: active ? null : () => Nav.resetTo(context, route),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Svg(icon(color), size: 22),
            const SizedBox(height: 4),
            Text(label, style: ts(11, weight: active ? bold : FontWeight.w400, color: color)),
          ],
        ),
      ),
    );
  }
}
