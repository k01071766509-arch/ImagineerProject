import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/app_icons.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';
import '../widgets/fish_widgets.dart';

/// 3. 메인(홈)
/// - 하루 기록하기 카드 → 4. 감정 담기
/// - [변경/11-01] 오늘의 필사 카드: 녹음 전 → 4. 감정 담기 / 녹음 후 → 9-3. 필사 탭
///   (작은 행운 카드와 필사 탭이 겹쳐서 하나로 합쳤어요. 3-1 작은 행운 화면은 더 이상 연결하지 않아요)
/// - 하단 탭: 기록 → 9. 기록, 어항 → 10. 어항
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'GOOD MORNING';
    if (hour < 18) return 'GOOD AFTERNOON';
    return 'GOOD EVENING';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Stack(
              fit: StackFit.expand,
              children: [
                const Positioned(top: -70, right: -70, child: BubbleDeco(size: 200)),
                const Positioned(top: 130, left: -60, child: BubbleDeco(size: 120, opacity: 0.7)),
                FillScrollView(
                  padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 20),
                  children: [
                    Text(_greeting(),
                        style: ts(12, weight: bold, color: AppColors.accent, letterSpacing: 1)),
                    const SizedBox(height: 10),
                    Text('오늘 하루도\n참 수고 많으셨어요', style: ts(20, weight: bold, height: 1.4)),
                    const SizedBox(height: 24),
                    _RecordCard(onTap: () => Nav.push(context, AppRoutes.recording)),
                    const SizedBox(height: 18),
                    const _TodayTranscriptCard(),
                    const SizedBox(height: 18),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.alpha(AppColors.white, 0.6),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Svg(AppIcons.flame(), size: 18),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text('마음을 기록하고 추천 문장을 필사하면, 어항의 물고기가 자라나요',
                                style: ts(12, color: AppColors.textInfo)),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const AppBottomNav(current: NavTab.home),
        ],
      ),
    );
  }
}

class _RecordCard extends StatelessWidget {
  const _RecordCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tap(
      onTap: onTap,
      child: AppCard(
        radius: 24,
        padding: const EdgeInsets.fromLTRB(20, 32, 20, 24),
        shadow: AppColors.cardShadow(0.10, 20, 6),
        child: Column(
          children: [
            Container(
              width: 132,
              height: 132,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const RadialGradient(
                  colors: [AppColors.white, AppColors.mint100, AppColors.mint200],
                  stops: [0.0, 0.7, 1.0],
                ),
                boxShadow: AppColors.cardShadow(0.22, 30, 10),
              ),
              child: Container(
                width: 78,
                height: 78,
                alignment: Alignment.center,
                decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                child: Svg(AppIcons.mic(AppColors.white), size: 30),
              ),
            ),
            const SizedBox(height: 14),
            Text('하루 기록하기', style: ts(16, weight: bold)),
            const SizedBox(height: 4),
            Text('이 감정을 목소리로 남겨보세요', style: ts(12, color: AppColors.textSub)),
            const SizedBox(height: 16),
            Text('탭하여 시작해요 ↑', style: ts(11, color: AppColors.textFaint)),
          ],
        ),
      ),
    );
  }
}

/// [변경/11-01] 오늘의 필사 카드 (작은 행운 카드 자리)
class _TodayTranscriptCard extends StatelessWidget {
  const _TodayTranscriptCard();

  @override
  Widget build(BuildContext context) {
    final store = GrowthStore.instance;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final type = store.todayType;
        final phrase = store.todayPhrase;
        final ready = type != null && phrase != null;
        final done = store.todayDone;

        final String subtitle;
        final String action;
        if (!ready) {
          subtitle = '오늘 마음을 기록하면 필사 문구가 열려요';
          action = '먼저 하루 기록하기';
        } else if (done) {
          subtitle = phrase!;
          action = '오늘의 필사 완료';
        } else {
          subtitle = phrase!;
          action = '탭하여 따라 적기';
        }

        return Tap(
          onTap: () => ready ? Nav.resetTo(context, AppRoutes.transcripts) : Nav.push(context, AppRoutes.recording),
          child: AppCard(
            radius: 20,
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: ready ? type!.light : AppColors.track,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: ready
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: FishSprite(type: type!, level: store.fish[type]!.level, size: 52, zoom: true),
                        )
                      : Svg(AppIcons.pencil(AppColors.textMuted), size: 24),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(ready ? '오늘의 필사 · ${type!.label}' : '오늘의 필사', style: ts(14, weight: bold)),
                      const SizedBox(height: 3),
                      Text(subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: ts(12, color: AppColors.textSub, height: 1.4)),
                      const SizedBox(height: 6),
                      Text(action, style: ts(11, weight: bold, color: done ? AppColors.textMuted : AppColors.primary)),
                    ],
                  ),
                ),
                const SizedBox(width: 14),
                Svg(AppIcons.chevronRight(AppColors.primary), size: 18),
              ],
            ),
          ),
        );
      },
    );
  }
}
