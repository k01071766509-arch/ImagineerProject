// [변경/11-01] 1031 회의: 필사를 기록 탭에서 빼서 별도 하단 탭으로 구성
//
// 9-3. 필사 (하단 탭)
// ① 웰니스 스코어에서 가장 높은 유형 = 오늘의 물고기
// ③ 그 유형(활력·안정·불안·피로)에 맞는 필사 문구를 추천
// ④ 사용자가 따라 적고 '필사 완료'
// ⑤ 오늘의 물고기에 경험치 → ⑥ 경험치가 차면 레벨업
// - 아래에는 지금까지의 필사 기록을 카테고리별(활력·안정·불안·피로)로 볼 수 있어요.

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/growth_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/app_icons.dart';
import '../widgets/bgm_bar.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/common.dart';
import '../widgets/fish_widgets.dart';

class TranscriptsScreen extends StatefulWidget {
  const TranscriptsScreen({super.key});

  @override
  State<TranscriptsScreen> createState() => _TranscriptsScreenState();
}

class _TranscriptsScreenState extends State<TranscriptsScreen> {
  final _controller = TextEditingController();

  /// 기록 목록 필터: null = 전체, 'lucky' = 작은 행운, 그 외 FishType 이름
  String? _filter;

  GrowthStore get _store => GrowthStore.instance;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _complete() {
    FocusScope.of(context).unfocus();
    if (_controller.text.trim().isEmpty) {
      showMockSnack(context, '추천 문구를 따라 적어 주세요');
      return;
    }
    final reward = _store.completeTodayTranscript();
    if (reward == null) return;
    _controller.clear();

    final name = '${reward.type.label} 물고기';
    if (reward.leveledUp) {
      _showLevelUp(reward);
    } else if (_store.fish[reward.type]!.isMax) {
      showMockSnack(context, '$name는 이미 다 자랐어요');
    } else {
      showMockSnack(context, '$name가 경험치 ${reward.gainedExp}을 얻었어요');
    }
  }

  void _showLevelUp(TranscriptReward reward) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(color: reward.type.light, shape: BoxShape.circle),
              child: ClipOval(child: FishSprite(type: reward.type, level: reward.level, size: 96, zoom: true)),
            ),
            const SizedBox(height: 16),
            Text('레벨 업!', style: ts(18, weight: bold)),
            const SizedBox(height: 6),
            Text(
              '${reward.type.label} 물고기가 Lv.${reward.level} ${fishLevelNames[reward.level]}(으)로 자랐어요',
              textAlign: TextAlign.center,
              style: ts(13, color: AppColors.textSub, height: 1.5),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: Text('닫기', style: ts(13, color: AppColors.textSub)),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              Nav.resetTo(context, AppRoutes.fishTank);
            },
            child: Text('어항 보러 가기', style: ts(13, weight: bold, color: AppColors.primary)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Column(
          children: [
            Expanded(
              child: AnimatedBuilder(
                animation: _store,
                builder: (context, _) => SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text('필사', style: ts(17, weight: bold)),
                      const SizedBox(height: 4),
                      Text('오늘의 감정에 맞는 문장을 따라 적으면 물고기가 자라요',
                          style: ts(12, color: AppColors.textSub)),
                      const SizedBox(height: 18),
                      _todaySection(),
                      const SizedBox(height: 14),
                      const BgmBar(compact: true),
                      const SizedBox(height: 28),
                      Text('나의 필사', style: ts(15, weight: bold)),
                      const SizedBox(height: 12),
                      _filterChips(),
                      const SizedBox(height: 14),
                      _history(),
                    ],
                  ),
                ),
              ),
            ),
            const AppBottomNav(current: NavTab.transcripts),
          ],
        ),
      ),
    );
  }

  // ───────── 오늘의 추천 문구 ─────────

  Widget _todaySection() {
    final type = _store.todayType;
    final phrase = _store.todayPhrase;

    // 아직 녹음 전
    if (type == null || phrase == null) {
      return AppCard(
        radius: 20,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 26),
        child: Column(
          children: [
            Svg(AppIcons.quote(), size: 22, height: 16),
            const SizedBox(height: 12),
            Text('오늘 마음을 기록하면\n감정에 맞는 필사 문구를 추천해 드려요',
                textAlign: TextAlign.center, style: ts(14, weight: bold, height: 1.6)),
            const SizedBox(height: 16),
            Tap(
              onTap: () => Nav.push(context, AppRoutes.recording),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 11),
                decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(999)),
                child: Text('감정 담으러 가기', style: ts(13, weight: bold, color: AppColors.white)),
              ),
            ),
          ],
        ),
      );
    }

    final f = _store.fish[type]!;
    final done = _store.todayDone;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // 오늘의 물고기
        Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: type.light, shape: BoxShape.circle, border: Border.all(color: type.dark, width: 2)),
              child: ClipOval(child: FishSprite(type: type, level: f.level, size: 40, zoom: true)),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('오늘의 감정 · ${type.label}', style: ts(13, weight: bold)),
                  const SizedBox(height: 2),
                  Text(
                    f.isMax ? '${type.label} 물고기 · Lv.${f.level} ${fishLevelNames[f.level]}'
                        : '${type.label} 물고기 · Lv.${f.level} · ${f.exp} / ${f.maxExp} EXP',
                    style: ts(11, color: AppColors.textSub),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        // 추천 문구
        AppCard(
          radius: 20,
          color: type.light,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
          shadow: AppColors.cardShadow(0.06),
          child: Column(
            children: [
              Svg(AppIcons.quote(), size: 22, height: 16),
              const SizedBox(height: 12),
              Text(phrase, textAlign: TextAlign.center, style: ts(16, weight: bold, height: 1.6)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (done)
          InfoBanner(text: '오늘의 필사를 마쳤어요. 다시 녹음하면 새로운 문구가 추천돼요.')
        else ...[
          Text('나만의 손글씨로 따라 적어보세요', style: ts(13, weight: bold, color: AppColors.textBody)),
          const SizedBox(height: 10),
          AppCard(
            padding: const EdgeInsets.all(18),
            child: SizedBox(
              height: 112,
              child: Stack(
                children: [
                  const Positioned.fill(
                    child: IgnorePointer(child: CustomPaint(painter: _LinedPaperPainter())),
                  ),
                  Positioned.fill(
                    child: TextField(
                      controller: _controller,
                      keyboardType: TextInputType.multiline,
                      textInputAction: TextInputAction.newline,
                      maxLines: null,
                      expands: true,
                      textAlignVertical: TextAlignVertical.top,
                      style: ts(13, height: 28 / 13),
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        isCollapsed: true,
                        hintText: '위 문장을 따라 적어보세요',
                        hintStyle: ts(13, color: AppColors.textMuted, height: 28 / 13),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          PrimaryButton(
            label: f.isMax ? '필사 완료' : '필사 완료 (+$expPerTranscript EXP)',
            onTap: _complete,
          ),
        ],
      ],
    );
  }

  // ───────── 필사 기록 ─────────

  Widget _filterChips() {
    final items = <(String?, String)>[
      (null, '전체'),
      for (final t in FishType.values) (t.name, t.label),
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final (key, label) in items) ...[
            Tap(
              onTap: () => setState(() => _filter = key),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: _filter == key ? AppColors.primary : AppColors.white,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: _filter == key ? AppColors.primary : AppColors.divider),
                ),
                child: Text(label,
                    style: ts(12, weight: bold, color: _filter == key ? AppColors.white : AppColors.textSub)),
              ),
            ),
            const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }

  Widget _history() {
    final list = _store.transcripts.where((r) {
      if (_filter == null) return true;
      if (_filter == 'lucky') return r.type == null;
      return r.type?.name == _filter;
    }).toList();

    if (list.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Text('아직 필사한 문장이 없어요', textAlign: TextAlign.center, style: ts(12, color: AppColors.textMuted)),
      );
    }

    return Column(
      children: [
        for (var i = 0; i < list.length; i++) ...[
          if (i > 0) const SizedBox(height: 12),
          _HistoryTile(record: list[i]),
        ],
      ],
    );
  }
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({required this.record});

  final TranscriptRecord record;

  @override
  Widget build(BuildContext context) {
    final type = record.type;
    final d = record.date;
    final date = '${d.year}.${d.month.toString().padLeft(2, '0')}.${d.day.toString().padLeft(2, '0')}';
    return AppCard(
      radius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: type?.light ?? const Color(0xFFEEF7EC),
              borderRadius: BorderRadius.circular(12),
            ),
            child: type == null
                ? Svg(AppIcons.clover(), size: 20)
                : Text(type.label, style: ts(11, weight: bold, color: AppColors.textDark)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.soundTitle == null ? date : '$date · ♪ ${record.soundTitle}',
                  style: ts(11, color: AppColors.textMuted),
                ),
                const SizedBox(height: 3),
                Text(record.phrase, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13, height: 1.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// 공책 줄 배경 (작은 행운 화면과 같은 모양)
class _LinedPaperPainter extends CustomPainter {
  const _LinedPaperPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE9F2E0)
      ..strokeWidth = 1;
    for (double y = 27.5; y < size.height; y += 28) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
