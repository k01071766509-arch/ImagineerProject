// [변경/10-26] 예시 값 → 실제 분석 결과

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import '../navigation/nav.dart';
import '../services/analysis_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';
import '../widgets/app_icons.dart';
import '../widgets/common.dart';

class WellnessScoreScreen extends StatelessWidget {
  const WellnessScoreScreen({super.key});

  static const _sample = AnalysisResult(
    wellnessScore: 72,
    positivity: 68,
    negativity: 24,
    stability: 76,
    vitality: 41,
    calm: 76,
    anxiety: 24,
    fatigue: 32,
    crisis: false,
    topEmotion: '',
    avgScores: {},
    area: '일/학업',
  );

  @override
  Widget build(BuildContext context) {
    final r = AnalysisSession.instance.result ?? _sample;

    return Scaffold(
      body: FillScrollView(
        padding: EdgeInsets.fromLTRB(24, topPad(context, 56), 24, bottomPad(context, 32)),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: BackArrow(onTap: () => Nav.backTo(context, AppRoutes.recording)),
          ),
          const SizedBox(height: 24),
          _scoreCard(r),
          if (r.crisis) ...[
            const SizedBox(height: 16),
            const _CrisisBanner(),
          ],
          const SizedBox(height: 16),
          _sourceCard(r.area),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _MiniStat(label: '활력', value: r.vitality / 100, color: AppColors.orange)),
              const SizedBox(width: 12),
              Expanded(child: _MiniStat(label: '안정', value: r.calm / 100, color: AppColors.mintBar)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _MiniStat(label: '불안', value: r.anxiety / 100, color: AppColors.coral)),
              const SizedBox(width: 12),
              Expanded(child: _MiniStat(label: '피로', value: r.fatigue / 100, color: AppColors.textMuted)),
            ],
          ),
          const SizedBox(height: 16),
          const Spacer(),
          PrimaryButton(
            label: '추천 사운드 듣기',
            onTap: () => Nav.push(context, AppRoutes.soundRecommend),
          ),
        ],
      ),
    );
  }

  Widget _scoreCard(AnalysisResult r) {
    return AppCard(
      radius: 22,
      padding: const EdgeInsets.fromLTRB(22, 26, 22, 22),
      shadow: AppColors.cardShadow(0.10, 24, 8),
      child: Column(
        children: [
          Text('WELLNESS SCORE', style: ts(12, weight: bold, color: AppColors.textSub, letterSpacing: 2)),
          const SizedBox(height: 8),
          Container(
            width: 120,
            height: 120,
            decoration: const BoxDecoration(color: Color(0xFFF2FBF8), shape: BoxShape.circle),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('${r.wellnessScore.round()}', style: ts(34, weight: bold, height: 1.2)),
                Text('/ 100', style: ts(11, color: AppColors.textSub)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(r.statusText, style: ts(15, weight: bold)),
          const SizedBox(height: 20),
          const Divider(height: 1, thickness: 1, color: AppColors.track),
          const SizedBox(height: 20),
          _EmotionRow(label: '긍정', value: r.positivity / 100, color: AppColors.primary),
          const SizedBox(height: 14),
          _EmotionRow(label: '안정', value: r.stability / 100, color: AppColors.mintBar),
          const SizedBox(height: 14),
          _EmotionRow(label: '부정', value: r.negativity / 100, color: AppColors.coral),
        ],
      ),
    );
  }

  Widget _sourceCard(String? area) {
    final text = area == null
        ? '이번에는 어떤 영역의 이야기인지\n찾지 못했어요'
        : "이 점수는 주로\n'$area' 영역에서 나온 감정이에요";
    return AppCard(
      color: const Color(0xFFFDF6E8),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      shadow: AppColors.cardShadow(0.06),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFFF6E6BF), borderRadius: BorderRadius.circular(12)),
            child: Svg(AppIcons.document(), size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: ts(14, weight: bold, height: 1.4))),
        ],
      ),
    );
  }
}

class _CrisisBanner extends StatelessWidget {
  const _CrisisBanner();

  static const Color _accent = Color(0xFFC9361D);

  @override
  Widget build(BuildContext context) {
    return AppCard(
      color: const Color(0xFFFFC9BA),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      shadow: AppColors.cardShadow(0.06),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFFFFAB93), borderRadius: BorderRadius.circular(12)),
            child: Svg(AppIcons.info(_accent), size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('많이 힘드셨겠어요.', style: ts(14, weight: bold, height: 1.4)),
                const SizedBox(height: 2),
                Text('혼자 견디기 어려우시다면 아래 번호로 연락해보세요.',
                    style: ts(12, weight: bold, color: AppColors.textDark, height: 1.5)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: AppColors.white, borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('정신건강위기상담전화', style: ts(12, weight: bold, color: AppColors.textDark)),
                      const SizedBox(width: 8),
                      Text('1577-0199', style: ts(14, weight: bold, color: _accent)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EmotionRow extends StatelessWidget {
  const _EmotionRow({required this.label, required this.value, required this.color});

  final String label;
  final double value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(width: 46, child: Text(label, style: ts(13))),
        const SizedBox(width: 10),
        Expanded(child: ProgressBar(value: value, color: color)),
        const SizedBox(width: 10),
        SizedBox(
          width: 38,
          child: Text('${(value * 100).round()}%',
              textAlign: TextAlign.right, style: ts(13, color: AppColors.textSub)),
        ),
      ],
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value, required this.color});

  final String label;
  final double value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(16),
      radius: 16,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: ts(12, color: AppColors.textSub)),
          const SizedBox(height: 6),
          Text('${(value * 100).round()}%', style: ts(20, weight: bold)),
          const SizedBox(height: 8),
          ProgressBar(value: value, color: color, height: 6, radius: 4),
        ],
      ),
    );
  }
}