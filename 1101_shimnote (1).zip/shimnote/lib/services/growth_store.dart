// [추가/11-01] 1031 회의 반영: 필사 탭 분리 · 필사로 물고기 성장 · 어항 배경음
//
// 앱 전체에서 함께 쓰는 "성장 상태"를 한곳에 모았어요.
// - 오늘의 물고기: 웰니스 스코어(활력·안정·불안·피로) 중 가장 높은 유형
// - 필사 문구: 4가지 카테고리, 오늘의 유형에 맞는 문구를 추천
// - 경험치: 추천 문구를 필사하면 해당 물고기만 경험치를 얻어요 (가장 높은 감정 하나만 반영)
// - 어항 배경음: 그날의 음원(오늘 들은 음원, 없으면 오늘 추천 음원)을 어항에서 다시 듣기
//
// ⚠️ 지금은 앱을 끄면 초기화되는 메모리 저장이에요.
//    Firestore 저장은 데이터 구조가 확정되면 이 파일 안에서만 바꾸면 돼요.

import 'package:flutter/foundation.dart';

import '../widgets/fish_widgets.dart' show FishType;
import 'analysis_service.dart';

// ───────────────────────── 경험치 규칙 (회의에서 숫자만 바꾸면 돼요) ─────────────────────────

/// 추천 문구 하나를 필사하면 얻는 경험치
const int expPerTranscript = 10;

/// 다음 레벨까지 필요한 경험치 (Lv.1→2, 2→3, 3→4, 4→5)
/// 기본값 기준: 한 물고기를 만렙(Lv.5)까지 키우려면 필사 14번
const List<int> expToNextLevel = [20, 30, 40, 50];

/// [테스트용] 녹음 없이 필사·어항 기능을 확인하고 싶을 때 오늘의 유형을 정해 둬요.
/// 예) FishType.calm 으로 바꾸면 '안정'이 오늘의 물고기가 됩니다. 확인이 끝나면 null 로 되돌리기
const FishType? demoTodayType = null;

/// [회의 확인용] true = 어항에 오늘의 물고기만 표시 / false = 4마리 모두 표시하고 오늘의 물고기만 강조
const bool showOnlyTodayFish = false;

// ───────────────────────── 필사 문구 (4가지 카테고리) ─────────────────────────

/// 카테고리별 필사 문구. 팀에서 정한 문구로 자유롭게 바꾸거나 늘려도 돼요.
const Map<FishType, List<String>> transcriptPhrases = {
  FishType.vitality: [
    '오늘의 반짝임은 내일의 나에게도 이어질 거예요.',
    '작은 기쁨을 알아보는 마음이 하루를 밝혀요.',
    '지금의 설렘을 천천히 오래 간직해요.',
    '내가 웃을 수 있었던 순간을 잊지 말아요.',
    '좋은 에너지는 나를 지나 누군가에게도 닿아요.',
  ],
  FishType.calm: [
    '천천히 걸어도 괜찮아요. 방향이 맞다면 충분해요.',
    '고요한 마음은 가장 단단한 쉼터예요.',
    '오늘은 이대로도 충분히 괜찮은 하루예요.',
    '숨을 고르고, 지금 이 순간에 머물러요.',
    '잔잔한 물결처럼 내 마음도 제자리를 찾아가요.',
  ],
  FishType.anxiety: [
    '걱정은 잠시 내려놓아도 괜찮아요.',
    '모든 것을 지금 해결하지 않아도 돼요.',
    '흔들리는 마음도 결국 제자리를 찾아요.',
    '불안은 내가 소중한 것을 지키고 있다는 신호예요.',
    '한 걸음씩, 할 수 있는 것부터 해 봐요.',
  ],
  FishType.fatigue: [
    '쉬어가는 것도 나아가는 방법이에요.',
    '오늘 하루 버텨 낸 나에게 고마워요.',
    '지친 날에는 조금 느려도 괜찮아요.',
    '충분히 쉬어야 다시 걸을 힘이 생겨요.',
    '오늘의 나에게 조금 더 다정하게.',
  ],
};

// ───────────────────────── 음원 목록 ─────────────────────────

/// 앱 안의 음원 정보. Firebase에 음원이 올라오면 [url]을 채우면 돼요.
class SoundItem {
  const SoundItem({required this.id, required this.title, required this.desc, this.url});

  final String id;
  final String title;
  final String desc;
  final String? url; // Firebase Storage 주소 (아직 비어 있음)
}

const List<SoundItem> soundCatalog = [
  SoundItem(id: 'water_echo', title: '물빛의 잔향', desc: '물속에 번지는 맑은 건반 사운드'),
  SoundItem(id: 'game_world', title: '게임 속 작은 세상', desc: '통통 튀는 게임 속 분위기의 사운드'),
  SoundItem(id: 'spring', title: '맑은 샘물 소리', desc: '바위 사이로 흐르는 맑은 샘물 소리'),
  SoundItem(id: 'rain', title: '잔잔한 빗소리', desc: '숨을 천천히 내쉬어 보세요'),
];

/// 오늘의 추천 음원 3곡 (사운드 추천 화면에 나오는 순서: 추천 카드 1개 + 아래 2개)
/// TODO(사운드): 사운드 추천 로직이 연결되면 분석 결과에 맞는 3곡 id를 돌려주도록 바꿔요.
const List<String> todayRecommendedSoundIds = ['water_echo', 'game_world', 'spring'];

SoundItem? soundById(String? id) {
  for (final s in soundCatalog) {
    if (s.id == id) return s;
  }
  return null;
}

// ───────────────────────── 데이터 모델 ─────────────────────────

/// 물고기 한 마리의 성장 상태
class FishProgress {
  FishProgress({this.level = 1, this.exp = 0});

  int level; // 1(치어) ~ 5(완성)
  int exp; //   현재 레벨 안에서 모은 경험치

  bool get isMax => level >= FishType.maxLevel;

  /// 다음 레벨까지 필요한 경험치 (만렙이면 마지막 단계 값으로 표시)
  int get maxExp => expToNextLevel[(level - 1).clamp(0, expToNextLevel.length - 1)];
}

/// 필사 기록 한 건
class TranscriptRecord {
  const TranscriptRecord({required this.date, required this.phrase, this.type, this.soundTitle});

  final DateTime date;
  final String phrase;
  final FishType? type; //      null 이면 '작은 행운' 필사
  final String? soundTitle; //  필사할 때 재생 중이던 어항 배경음
}

/// 필사를 마쳤을 때의 결과 (화면에서 레벨업 안내에 사용)
class TranscriptReward {
  const TranscriptReward({required this.type, required this.gainedExp, required this.leveledUp, required this.level});

  final FishType type;
  final int gainedExp;
  final bool leveledUp;
  final int level;
}

// ───────────────────────── 상태 저장소 ─────────────────────────

class GrowthStore extends ChangeNotifier {
  GrowthStore._();
  static final GrowthStore instance = GrowthStore._();

  /// 처음에는 4마리 모두 치어(Lv.1)
  final Map<FishType, FishProgress> fish = {for (final t in FishType.values) t: FishProgress()};

  final List<TranscriptRecord> transcripts = [];

  // ── 오늘의 물고기 ──

  static final Object _demoKey = Object();

  /// 오늘의 분석 결과를 가리키는 값. 새로 녹음하면 바뀌어서 새 추천 문구가 나와요.
  Object? get _todayKey => AnalysisSession.instance.result ?? (demoTodayType != null ? _demoKey : null);

  /// 웰니스 스코어에서 가장 높은 유형. 아직 녹음하지 않았으면 null
  FishType? get todayType {
    final r = AnalysisSession.instance.result;
    if (r == null) return demoTodayType;
    final scores = {
      FishType.vitality: r.vitality,
      FishType.calm: r.calm,
      FishType.anxiety: r.anxiety,
      FishType.fatigue: r.fatigue,
    };
    var best = FishType.vitality;
    for (final e in scores.entries) {
      if (e.value > scores[best]!) best = e.key;
    }
    return best;
  }

  // ── 오늘의 추천 문구 ──

  Object? _phraseKey;
  String? _phrase;
  final Map<FishType, int> _nextPhraseIndex = {for (final t in FishType.values) t: 0};

  /// 오늘의 유형에 맞는 추천 문구 (분석 결과 하나당 한 문구, 녹음할 때마다 다음 문구로)
  String? get todayPhrase {
    final type = todayType;
    final key = _todayKey;
    if (type == null || key == null) return null;
    if (!identical(key, _phraseKey)) {
      final list = transcriptPhrases[type]!;
      final i = _nextPhraseIndex[type]!;
      _phrase = list[i % list.length];
      _nextPhraseIndex[type] = i + 1;
      _phraseKey = key;
    }
    return _phrase;
  }

  Object? _rewardedKey;

  /// 오늘의 추천 문구를 이미 필사했는지 (분석 결과 하나당 경험치는 한 번만)
  bool get todayDone {
    final key = _todayKey;
    return key != null && identical(key, _rewardedKey);
  }

  /// 추천 문구 필사 완료 → 오늘의 물고기에 경험치
  TranscriptReward? completeTodayTranscript() {
    final type = todayType;
    final phrase = todayPhrase;
    if (type == null || phrase == null || todayDone) return null;

    _rewardedKey = _todayKey;
    transcripts.insert(0, TranscriptRecord(date: DateTime.now(), phrase: phrase, type: type, soundTitle: _bgmTitleIfPlaying));

    final f = fish[type]!;
    var leveledUp = false;
    if (!f.isMax) {
      f.exp += expPerTranscript;
      while (!f.isMax && f.exp >= f.maxExp) {
        f.exp -= f.maxExp;
        f.level++;
        leveledUp = true;
      }
      if (f.isMax) f.exp = f.maxExp; // 만렙이면 게이지를 꽉 채워 보여 줘요
    }
    notifyListeners();
    return TranscriptReward(type: type, gainedExp: expPerTranscript, leveledUp: leveledUp, level: f.level);
  }

  /// 작은 행운(홈) 필사 저장 — 감정 카테고리가 없어서 경험치는 없어요
  void addLuckyTranscript(String phrase) {
    transcripts.insert(0, TranscriptRecord(date: DateTime.now(), phrase: phrase, soundTitle: _bgmTitleIfPlaying));
    notifyListeners();
  }

  // ── 그날의 음원 (어항 배경음) ──
  // [변경/11-01] 수집 음원 중 고르기 → '그날의 음원'을 어항에서 다시 듣기로 변경

  /// 지금 재생 화면에서 듣는 음원 (사운드 추천 → 재생으로 넘길 때 사용)
  String? nowPlayingId;

  /// 오늘 분석 뒤에 직접 들은 음원
  Object? _soundKey;
  String? _todaySoundId;

  bool bgmPlaying = false;

  /// 그날의 음원 (어항에서 지금 선택된 곡)
  /// - 어항에서 직접 고른 곡, 또는 오늘 분석 뒤 사운드 재생 화면에서 마지막으로 들은 곡
  /// - 아직 아무것도 듣지 않았으면 오늘 추천 1순위 곡
  /// - 오늘 녹음 전이면 null
  SoundItem? get todaySound {
    final key = _todayKey;
    if (key == null) return null;
    if (identical(key, _soundKey)) return soundById(_todaySoundId);
    return soundById(todayRecommendedSoundIds.first);
  }

  /// 어항에서 고를 수 있는 오늘의 곡들 (추천 3곡 + 추천 밖에서 들은 곡이 있으면 함께)
  List<SoundItem> get todaySounds {
    if (_todayKey == null) return const [];
    final ids = [...todayRecommendedSoundIds];
    final current = todaySound?.id;
    if (current != null && !ids.contains(current)) ids.add(current);
    return [for (final id in ids) if (soundById(id) != null) soundById(id)!];
  }

  /// 어항에서 곡 고르기 → 바로 재생
  void selectTodaySound(String id) {
    final key = _todayKey;
    if (key == null) return;
    _soundKey = key;
    _todaySoundId = id;
    bgmPlaying = true;
    notifyListeners();
    // TODO(사운드): 실제 재생 연결 (todaySound?.url)
  }

  String? get _bgmTitleIfPlaying => bgmPlaying ? todaySound?.title : null;

  void startSound(String id, {bool notify = true}) {
    nowPlayingId = id;
    final key = _todayKey;
    if (key != null) {
      _soundKey = key;
      _todaySoundId = id;
    }
    if (notify) notifyListeners();
  }

  void toggleBgm() {
    if (todaySound == null) return;
    bgmPlaying = !bgmPlaying;
    notifyListeners();
    // TODO(사운드): Firebase 음원이 준비되면 여기서 실제 재생/일시정지를 연결해요. (todaySound?.url)
  }
}
